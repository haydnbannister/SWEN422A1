This system consists of three files:
index.html - A homepage that contains links to two separate visualisations
home-advantage.html - A visualisation of the impact of home advantage across the seasons
season-data.html - A visualisation of the matches played accross each season

This system must be run as a local server. 
This can be done on any machine with python 3 installed using the command: python3 -m http.server
This can also be done on the ECS Unix machines with the command: php -S localhost:8000
